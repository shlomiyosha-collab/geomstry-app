# גאומטריה על הלוח – אפליקציית אנדרואיד

אפליקציה ללימוד: שטח והיקף מלבן, שמות מצולעים, סוגי משולשים, ותרגול.
האפליקציה היא עטיפת WebView סביב `app/src/main/assets/index.html`.

## יצירת APK דרך GitHub (בלי להתקין כלום)
1. צרו מאגר חדש ב-GitHub והעלו אליו את כל תוכן התיקייה (כולל `.github`).
2. היכנסו ללשונית **Actions** ← **Build APK** ← **Run workflow** (או פשוט בצעו push ל-main).
3. כשהריצה מסתיימת, הורידו את `geometry-app-apk` מסעיף **Artifacts** ופתחו את ה-ZIP.
4. העבירו את `app-debug.apk` לטלפון והתקינו (יש לאשר "התקנה ממקורות לא ידועים").

## בנייה מקומית
דרושים JDK 17, Android SDK ו-Gradle 8.7: `gradle assembleDebug`
הקובץ: `app/build/outputs/apk/debug/app-debug.apk`

## עריכת התוכן
כל התוכן והעיצוב נמצאים בקובץ `app/src/main/assets/index.html`.
